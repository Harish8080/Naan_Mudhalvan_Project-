This repository contains a project titled "Phishing URL Detector," designed to identify phishing websites that compromise user security by collecting data without the users' consent or knowledge.
The project employs machine learning algorithms, implemented in the Python programming language, to effectively detect phishing websites.
The project utilizes a curated dataset to train a machine learning model for detecting phishing websites.
I have attached the powerpoint presentation which contains the detailed explanation for the Naan Mudhalvan project on phishing URL problem and the proposed solution
